PCPhaser (copyright 2013 Universidad de Granada) is an application which
allows you to use the EIGENSOFT package to obtain PCA graphs from the
individual's haplotypes, rather than from their genotypes.

-----    SYSTEM REQUIREMENTS    ----

PCPhaser can be run only in Linux architectures, and you will need to
install the following packages:
- gcc 4.6 or newer, in order to run EIGENSOFT.
 * For Debian-based distributions: sudo apt-get install build-essential
 * For Fedora / CentOS: yum install gcc
- moreutils package, in order to use the sponge tool.
 * For Debian-based distributions: apt-get install moreutils
 * For Fedora / CentOS: yum install moreutils
- lapack package, in order to compute the eigenvectors.
 * For Debian-based distributions: apt-get install liblapack-dev
 * For Fedora / CentOS: yum install lapack
- gnuplot package, in order to draw the graphs.
 * For Debian-based distributions: apt-get install gnuplot
 * For Fedora / CentOS: yum install gnuplot

You will not need to install EIGENSOFT, since a copy of the package
-version 4.2- is included in the application folder. However, you must
not move the script "PCPhaser.sh", or it will not work properly, since
it uses relative paths to other scripts in the application folder.

-----         ARGUMENTS         ----

PCPhaser requires five arguments, and may be provided with a flag too,
as follows:
./PCPhaser.sh [INPUT_FOLDER] [OUTPUT_FOLDER] [OUTPUT_PREFIX] [WIDTH] [HEIGHT] [--silent]

- INPUT_FOLDER is the path containing the ".ped" and the ".map" files
with the information about the individuals and the loci. The files can
be named in any way, it is only assumed that:
1. All SNPs from all the individuals from all the populations that
belong to the same chromosome are in the same file.
2.- Both ".ped" and ".map" files can contain an integer number just
before the extension, indicating the chromosome number.
3.- There are as many ".map" files as chromosomes considered in the
sample, and they can be numbered before the extension too.

- OUTPUT_FOLDER is the path in which the new files will be created. If
the execution ends succesfully, in this folder there will be:
1. As many ".ped" files as in INPUT_FOLDER, named the same way,
containing the splitted haplotypes.
2. An ".evec" file, containing the results of the PCA analysis.
3. A ".png" file, representing the PCA graph.

- OUTPUT_PREFIX is the name that will be given to the output ".evec" and
".png" files.

- WIDTH is the widht, in pixels, for the output PCA graph.

- HEIGHT is the height, in pixels, for the output PCA graph.

- --silent is an optional flag that when present, prevents the program
to open a window displaying the graph after finishing the execution.

-----         FILE TYPES        ----

PCPhaser uses the PLINK format for the input and output ".ped" and
".map" files, which is described here:
- http://pngu.mgh.harvard.edu/~purcell/plink/data.shtml#ped
- http://pngu.mgh.harvard.edu/~purcell/plink/data.shtml#map

The 6th column of ".ped" files -the phenotype- should contain the name
of the population where the individual belongs to. As an example, the
following ".ped" file has 5 individuals, 3 belonging to the HapMap
population CEPH (CEU) and 2 to the HapMap population from Southest USA
with African ancestry (ASW):

2427 2427_19909 0 0 2 ASW 2 2 2 2 2 4 1 1 3 1 3 1 2 4 4 2 3 3 1 1 1 3 4 4 2 2 2 2 2 2 1 2 1 1 1 1 1 3 3 4
2446 2446_20127 0 0 2 ASW 2 2 2 2 2 2 1 1 3 3 3 3 2 2 4 4 3 3 1 3 1 1 4 4 2 2 1 2 4 2 2 1 3 1 1 1 3 3 4 4
1463 1463_12890 0 0 2 CEU 2 2 2 2 2 2 1 1 1 3 1 3 4 2 2 4 3 3 1 1 3 1 4 4 2 2 2 1 2 4 2 2 1 3 1 1 3 3 4 4
1463 1463_12889 0 0 1 CEU 2 2 2 2 2 2 1 1 3 3 3 3 2 2 4 4 3 1 3 1 1 1 4 4 2 2 2 2 2 2 1 1 1 1 1 1 3 3 4 4
1424 1424_11931 0 0 2 CEU 2 2 2 2 2 2 1 1 3 3 3 3 2 2 4 4 3 3 1 1 1 1 4 4 2 2 2 2 2 2 1 1 1 1 1 1 3 3 4 4

-----        INPUT FILES        ----

For PCPhaser to work, input ".ped" files must contain phased genotypes.
Therefore, alleles at every marker are always considered ordered so that
alleles in the first position of a genotype belong to the same
homologous chromosome. As an example, the second individual in the
".ped" file above (ID# 2446_20127) has haplotypes
"22213324311421423134 / 22213324331422211134".

-----       OUTPUT TYPES        ----

For each input ".ped" file with m lines corresponding to n different
individuals, PCPhaser will output another ".ped" file with 2m lines,
i.e., 2 for each individual, with their haplotypes, but duplicating each
allele. As an example, if an individual haplotype is "24322", the
haplotype with duplicated alleles will be "2244332222". The only reason
to duplicate alleles is technical, as PCPhaser has been implemented as a
wrapper of EIGENSOFT. Therefore, lines in the output ".ped" file
corresponding to individual 2446_20127 will have the following content:

2446 2446_20127_1 0 0 2 ASW 2 2 2 2 2 2 1 1 3 3 3 3 2 2 4 4 3 3 1 1 1 1 4 4 2 2 1 1 4 4 2 2 3 3 1 1 3 3 4 4
2446 2446_20127_2 0 0 2 ASW 2 2 2 2 2 2 1 1 3 3 3 3 2 2 4 4 3 3 3 3 1 1 4 4 2 2 2 2 2 2 1 1 1 1 1 1 3 3 4 4

-----        USE EXAMPLE        ----
You can test the application using the example data included in the
application, by running the following command:
./PCPhaser.sh exampleIN/ exampleOUT/ ASW+CEU 1000 800

When the proccess is completed, a window showing the PCA graph will pop
out by default. If you are going to work with huge data files, it is
strongly recommended to run the program in the background and in silent
mode:
nohup ./PCPhaser.sh exampleIN/ exampleOUT/ ASW+CEU 1000 800 --silent &

The plot drawn by PCPhaser from this example can be seen at http://bios.ugr.es/PCPhaser/ASW+CEU.png.
